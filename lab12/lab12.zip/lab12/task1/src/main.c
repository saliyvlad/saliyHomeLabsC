#include <stdio.h>
#include "background.h"

void main(void){

    start_background_system();
    background_system_msg("echo Task1 Success!");
}